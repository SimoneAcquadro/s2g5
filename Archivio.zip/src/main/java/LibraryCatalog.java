import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class LibraryCatalog implements CatalogManager {
    private List<CatalogItem> catalog;

    public LibraryCatalog() {
        this.catalog = new ArrayList<>();
    }

    @Override
    public void addItem(CatalogItem item) {
        catalog.add(item);
    }

    @Override
    public void removeItem(String isbn) {
        catalog.removeIf(item -> item.getIsbn().equals(isbn));
    }

    @Override
    public Optional<CatalogItem> findByISBN(String isbn) {
        return catalog.stream()
                .filter(item -> item.getIsbn().equals(isbn))
                .findFirst();
    }

    @Override
    public List<CatalogItem> findByYear(int year) {
        return catalog.stream()
                .filter(item -> item.getYear() == year)
                .collect(Collectors.toList());
    }

    @Override
    public List<CatalogItem> findByAuthor(String author) {
        return catalog.stream()
                .filter(item -> item instanceof Book && ((Book) item).getAuthor().equals(author))
                .collect(Collectors.toList());
    }

    @Override
    public void saveCatalog(List<CatalogItem> catalog, String filename) throws IOException {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(filename))) {
            outputStream.writeObject(catalog);
        }
    }

    @Override
    public List<CatalogItem> loadCatalog(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename))) {
            return (List<CatalogItem>) inputStream.readObject();
        }
    }
}
