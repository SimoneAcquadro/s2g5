import java.io.Serializable;

class Magazine extends CatalogItem implements Serializable {
    private Periodicity periodicity;

    public Magazine(String isbn, String title, int year, int pages, String author, Periodicity periodicity) {
        super(isbn, title, year, pages, author);
        this.periodicity = periodicity;
    }
}
