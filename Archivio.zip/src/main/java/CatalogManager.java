import java.io.IOException;
import java.util.List;
import java.util.Optional;

interface CatalogManager {
    void addItem(CatalogItem item);
    void removeItem(String isbn);
    Optional<CatalogItem> findByISBN(String isbn);
    List<CatalogItem> findByYear(int year);
    List<CatalogItem> findByAuthor(String author);
    void saveCatalog(List<CatalogItem> catalog, String filename) throws IOException;
    List<CatalogItem> loadCatalog(String filename) throws IOException, ClassNotFoundException;
}
