import java.io.Serializable;

class Book extends CatalogItem implements Serializable {
    private String author;
    private String genre;

    public Book(String isbn, String title, int year, int pages, String author, String genre) {
        super(isbn, title, year, pages, author);
        this.author = author;
        this.genre = genre;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }
}
