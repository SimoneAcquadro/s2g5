import java.io.Serializable;

class CatalogItem implements Serializable {
    private String isbn;
    private String title;
    private int year;
    private int pages;
    private String author;

    public CatalogItem(String isbn, String title, int year, int pages, String author) {
        this.isbn = isbn;
        this.title = title;
        this.year = year;
        this.pages = pages;
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public Integer getYear() {
        return year;
    }

    public Integer getPages() {
        return pages;
    }

    public String getAuthor() {
        return author;
    }
}

