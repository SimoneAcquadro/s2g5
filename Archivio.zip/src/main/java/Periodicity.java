enum Periodicity {
    WEEKLY, MONTHLY, SEMIANNUAL
}
