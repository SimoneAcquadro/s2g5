import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        // Creare un'istanza di LibraryCatalog
        LibraryCatalog libraryCatalog = new LibraryCatalog();

        // Aggiungere alcuni elementi al catalogo
        libraryCatalog.addItem(new Book("1234567890", "Il Signore degli Anelli", 1954, 1178, "J.R.R. Tolkien", "Fantasy"));
        libraryCatalog.addItem(new Magazine("9876543210", "National Geographic", 2023, 100, "National Geographic Society", Periodicity.MONTHLY));

        // Caricare il catalogo da file
        try {
            List<CatalogItem> loadedCatalog = libraryCatalog.loadCatalog("catalog.dat");
            System.out.println("Catalogo caricato:");
            for (CatalogItem item : loadedCatalog) {
                System.out.println(item.getTitle());
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Errore durante il caricamento del catalogo: " + e.getMessage());
        }

        // Esempio di utilizzo dei metodi di ricerca
        Optional<CatalogItem> foundItem = libraryCatalog.findByISBN("1234567890");
        if (foundItem.isPresent()) {
            System.out.println("Libro trovato: " + foundItem.get().getTitle());
        } else {
            System.out.println("Libro non trovato.");
        }

        List<CatalogItem> booksByAuthor = libraryCatalog.findByAuthor("J.R.R. Tolkien");
        System.out.println("Libri dell'autore J.R.R. Tolkien:");
        for (CatalogItem item : booksByAuthor) {
            System.out.println(item.getTitle());
        }
    }
}
